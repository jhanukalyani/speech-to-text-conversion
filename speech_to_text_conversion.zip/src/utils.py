"""utils.py
Text tokenizer helpers: char-level map and CTC label utilities.
"""
import string
import numpy as np

# Define a simple alphabet: lowercase letters, space, apostrophe
ALPHABET = list("' " + string.ascii_lowercase)  # e.g. "' abc...z"
# CTC requires an additional blank label; we'll map blank to len(ALPHABET)
BLANK_TOKEN = ''
CHAR_TO_IDX = {c: i for i, c in enumerate(ALPHABET)}
IDX_TO_CHAR = {i: c for c, i in CHAR_TO_IDX.items()}

def text_to_int_sequence(text):
    """Convert text to sequence of ints (char-level)."""
    text = text.lower()
    seq = []
    for ch in text:
        if ch in CHAR_TO_IDX:
            seq.append(CHAR_TO_IDX[ch])
    return np.array(seq, dtype=np.int32)

def int_sequence_to_text(seq):
    """Convert int sequence back to text."""
    return ''.join(IDX_TO_CHAR.get(int(x), '') for x in seq)

def ctc_decode(predictions):
    """Greedy CTC decode. predictions: (time, vocab_size) logits or probs."""
    # take argmax each time step
    argmax = predictions.argmax(axis=-1)
    # collapse repeats and remove blanks (we don't use explicit blank index here, treat as -1)
    out = []
    prev = None
    for a in argmax:
        if a != prev and a in IDX_TO_CHAR:
            out.append(a)
        prev = a
    return int_sequence_to_text(out)
