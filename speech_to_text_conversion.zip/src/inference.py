"""inference.py
Load a trained base_model (the speech-to-text model that outputs softmax over chars) and run greedy decoding.
Usage:
  python src/inference.py --model models/base_model.h5 --wav path/to/file.wav
"""
import argparse
import numpy as np
import tensorflow as tf
from src.preprocess import load_wav, compute_mel_spectrogram
from src.utils import int_sequence_to_text, ctc_decode

def transcribe(model_path, wav_path, n_mels=128):
    base_model = tf.keras.models.load_model(model_path)
    wav = load_wav(wav_path)
    feat = compute_mel_spectrogram(wav, n_mels=n_mels)
    inp = np.expand_dims(feat, axis=0)  # batch 1
    pred = base_model.predict(inp)
    # pred shape: (1, time, vocab)
    pred = pred[0]
    text = ctc_decode(pred)
    return text

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', type=str, required=True)
    parser.add_argument('--wav', type=str, required=True)
    parser.add_argument('--n_mels', type=int, default=128)
    args = parser.parse_args()
    print('Transcribing', args.wav)
    print(transcribe(args.model, args.wav, n_mels=args.n_mels))
