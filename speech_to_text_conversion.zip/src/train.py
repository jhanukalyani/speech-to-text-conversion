"""train.py
Example training script. Assumes you have folder structure:
data/
  train/
    wavs (*.wav)
    transcripts.txt  # lines: filename.wav<TAB>transcript
  val/
    ...
This script is simplified and intended for learning. Use TFRecords / tf.data for performance.
"""
import os
import argparse
import numpy as np
import tensorflow as tf
from tqdm import tqdm
from src.preprocess import load_wav, compute_mel_spectrogram
from src.utils import text_to_int_sequence
from src.model import build_model, ctc_loss_lambda

def parse_transcripts(transcript_file, data_dir):
    items = []
    with open(transcript_file, 'r', encoding='utf-8') as f:
        for line in f:
            parts = line.strip().split('\t')
            if len(parts) >= 2:
                wav, text = parts[0], parts[1]
                wav_path = os.path.join(data_dir, wav)
                if os.path.exists(wav_path):
                    items.append((wav_path, text))
    return items

def generator(items, batch_size=8, max_input_len=800, n_mels=128):
    # simple generator that yields batches of (inputs, labels, input_length, label_length)
    while True:
        X_batch = []
        labels = []
        input_lengths = []
        label_lengths = []
        for wav_path, text in items:
            wav = load_wav(wav_path)
            feat = compute_mel_spectrogram(wav, n_mels=n_mels)
            X_batch.append(feat)
            seq = text_to_int_sequence(text)
            labels.append(seq)
            input_lengths.append(feat.shape[0]//1)
            label_lengths.append(len(seq))
            if len(X_batch) == batch_size:
                # pad X_batch to same time dimension
                max_t = max(x.shape[0] for x in X_batch)
                input_dim = X_batch[0].shape[1]
                X_padded = np.zeros((batch_size, max_t, input_dim), dtype=np.float32)
                for i, x in enumerate(X_batch):
                    X_padded[i, :x.shape[0], :] = x
                # pad labels with -1 (ctc expects ints; we'll convert to ragged later)
                max_label = max(len(l) for l in labels)
                labels_padded = np.ones((batch_size, max_label), dtype=np.int32) * -1
                for i, l in enumerate(labels):
                    labels_padded[i, :len(l)] = l
                yield {
                    'input': X_padded,
                    'labels': labels_padded,
                    'input_length': np.array(input_lengths, dtype=np.int32),
                    'label_length': np.array(label_lengths, dtype=np.int32)
                }
                X_batch, labels, input_lengths, label_lengths = [], [], [], []

def build_training_model(input_dim, vocab_size):
    # Keras functional model with CTC loss as a lambda layer
    from tensorflow.keras import backend as K
    inputs = tf.keras.layers.Input(shape=(None, input_dim), name='input')
    labels = tf.keras.layers.Input(shape=(None,), dtype='int32', name='labels')
    input_length = tf.keras.layers.Input(shape=(1,), dtype='int32', name='input_length')
    label_length = tf.keras.layers.Input(shape=(1,), dtype='int32', name='label_length')

    base_model = build_model(input_dim, vocab_size)
    y_pred = base_model(inputs)

    loss_out = tf.keras.layers.Lambda(ctc_loss_lambda, output_shape=(1,), name='ctc')(
        [y_pred, labels, input_length, label_length])

    model = tf.keras.Model(inputs=[inputs, labels, input_length, label_length], outputs=loss_out)
    model.compile(optimizer=tf.keras.optimizers.Adam(1e-4), loss={'ctc': lambda y_true, y_pred: y_pred})
    return model, base_model

def main(args):
    train_trans = os.path.join(args.data_dir, 'train', 'transcripts.txt')
    val_trans = os.path.join(args.data_dir, 'val', 'transcripts.txt')
    train_items = parse_transcripts(train_trans, os.path.join(args.data_dir, 'train'))
    val_items = parse_transcripts(val_trans, os.path.join(args.data_dir, 'val'))

    if len(train_items) == 0:
        print('No training items found. Make sure data directory and transcripts are present.')
        return

    # infer input_dim from first file
    sample_wav = train_items[0][0]
    sample_feat = compute_mel_spectrogram(load_wav(sample_wav), n_mels=args.n_mels)
    input_dim = sample_feat.shape[1]
    print('Input dim (n_mels):', input_dim)

    model, base_model = build_training_model(input_dim, args.vocab_size)
    model.summary()

    train_gen = generator(train_items, batch_size=args.batch_size, n_mels=args.n_mels)
    val_gen = generator(val_items, batch_size=args.batch_size, n_mels=args.n_mels)

    steps_per_epoch = max(1, len(train_items) // args.batch_size)
    validation_steps = max(1, len(val_items) // args.batch_size)

    checkpoint = tf.keras.callbacks.ModelCheckpoint(
        filepath=os.path.join(args.save_dir, 'best.h5'),
        monitor='val_loss',
        save_best_only=True,
        save_weights_only=False
    )
    os.makedirs(args.save_dir, exist_ok=True)

    model.fit(
        train_gen,
        steps_per_epoch=steps_per_epoch,
        epochs=args.epochs,
        validation_data=val_gen,
        validation_steps=validation_steps,
        callbacks=[checkpoint]
    )

    # Save final base model too
    base_model.save(os.path.join(args.save_dir, 'base_model.h5'))
    print('Training finished. Models saved to', args.save_dir)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_dir', type=str, required=True, help='Path to data folder (contains train/ and val/)')
    parser.add_argument('--epochs', type=int, default=10)
    parser.add_argument('--batch_size', type=int, default=8)
    parser.add_argument('--n_mels', type=int, default=128)
    parser.add_argument('--vocab_size', type=int, default=28)  # matches utils ALPHABET size
    parser.add_argument('--save_dir', type=str, default='models')
    args = parser.parse_args()
    main(args)
