"""model.py
Build a small Conv + BiLSTM model and provide a CTC loss lambda layer for Keras.
"""
import tensorflow as tf

def build_model(input_dim, output_dim, rnn_units=128):
    # input_dim: number of feature bins (e.g., n_mels or n_mfcc)
    # Input shape: (time, input_dim)
    inputs = tf.keras.layers.Input(shape=(None, input_dim), name='input')

    # Add a couple of 1D conv layers (time-distributed)
    x = tf.keras.layers.Conv1D(64, kernel_size=11, strides=2, padding='same', activation='relu')(inputs)
    x = tf.keras.layers.BatchNormalization()(x)
    x = tf.keras.layers.Conv1D(128, kernel_size=11, strides=1, padding='same', activation='relu')(x)
    x = tf.keras.layers.BatchNormalization()(x)

    # Bidirectional RNNs
    x = tf.keras.layers.Bidirectional(tf.keras.layers.GRU(rnn_units, return_sequences=True))(x)
    x = tf.keras.layers.Bidirectional(tf.keras.layers.GRU(rnn_units, return_sequences=True))(x)

    # Dense to output dim (+1 for CTC blank if you like, but we'll not append blank explicitly)
    x = tf.keras.layers.Dense(output_dim + 1, activation='linear')(x)  # +1 for blank
    # softmax over last axis for CTC
    y_pred = tf.keras.layers.Activation('softmax', name='y_pred')(x)

    # Model for inference
    model = tf.keras.Model(inputs=inputs, outputs=y_pred)
    return model

# CTC loss wrapper (used in training script)
def ctc_loss_lambda(args):
    y_pred, labels, input_length, label_length = args
    # y_pred shape: (batch, time, vocab)
    # Need to transpose to time major for tf.nn.ctc_loss if using logits; but tf.keras.backend.ctc_batch_cost handles it
    return tf.keras.backend.ctc_batch_cost(labels, y_pred, input_length, label_length)
