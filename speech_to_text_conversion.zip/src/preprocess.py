"""preprocess.py
Utilities to load WAV, compute log-mel spectrograms or MFCCs.
"""
import os
import numpy as np
import librosa

def load_wav(path, sr=16000):
    wav, _ = librosa.load(path, sr=sr)
    return wav

def compute_mel_spectrogram(wav, sr=16000, n_mels=128, n_fft=1024, hop_length=256):
    # return log-mel spectrogram
    S = librosa.feature.melspectrogram(y=wav, sr=sr, n_mels=n_mels, n_fft=n_fft, hop_length=hop_length)
    S_db = librosa.power_to_db(S, ref=np.max)
    # Normalize to roughly -1..1
    S_norm = (S_db - S_db.mean()) / (S_db.std() + 1e-9)
    return S_norm.T  # time x n_mels

def compute_mfcc(wav, sr=16000, n_mfcc=40, n_fft=1024, hop_length=256):
    mfcc = librosa.feature.mfcc(y=wav, sr=sr, n_mfcc=n_mfcc, n_fft=n_fft, hop_length=hop_length)
    mfcc = (mfcc - mfcc.mean()) / (mfcc.std() + 1e-9)
    return mfcc.T  # time x n_mfcc

if __name__ == '__main__':
    import sys
    p = sys.argv[1]
    wav = load_wav(p)
    mel = compute_mel_spectrogram(wav)
    print('mel shape (time_steps, n_mels):', mel.shape)
