# sample_download.sh
# Example script to download Speech Commands (via tensorflow_datasets) and prepare a transcripts file.
# Run after installing requirements.
python - <<'PY'
import tensorflow_datasets as tfds
import os
import soundfile as sf
ds, info = tfds.load('speech_commands', split='train', with_info=True, shuffle_files=False)
out_dir = 'data/train'
os.makedirs(out_dir, exist_ok=True)
count = 0
with open(os.path.join(out_dir, 'transcripts.txt'), 'w', encoding='utf-8') as t:
    for ex in tfds.as_numpy(ds.take(500)):  # take small subset for quick experiments
        audio = ex['audio']
        label = ex['label']
        # label is an int mapped via info features
        # Convert label int to string label
        label_str = info.features['label'].int2str(label)
        wav_name = f'sc_{count}.wav'
        sf.write(os.path.join(out_dir, wav_name), audio, 16000)
        # For speech_commands the label is a single word - use as transcript
        t.write(wav_name + '\t' + label_str + '\n')
        count += 1
print('Saved', count, 'files to', out_dir)
PY
