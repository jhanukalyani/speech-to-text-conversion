# Speech-to-Text (TensorFlow) - Beginner Project

## Overview
This project implements a simple Speech-to-Text pipeline using TensorFlow and Keras.
It uses audio preprocessing (log-mel spectrograms / MFCC), a small conv + BiLSTM + CTC model,
and simple greedy decoding for inference.

## Structure
```
speech_to_text_tensorflow/
├─ src/
│  ├─ preprocess.py      # audio loading & feature extraction
│  ├─ utils.py           # mapping chars <-> ints and helpers
│  ├─ model.py           # build keras model with CTC loss
│  ├─ train.py           # training loop
│  └─ inference.py       # load model and run transcription
├─ requirements.txt
└─ README.md
```

## Quick start (on your machine)
1. Create a Python virtualenv and activate it:
   ```bash
   python -m venv venv
   source venv/bin/activate   # On Windows: venv\Scripts\activate
   pip install -r requirements.txt
   ```

2. Download a dataset. Two easy options:
   - Use TensorFlow Datasets (small subsets) - see `sample_download.sh`
   - Or download a subset of LibriSpeech / your own WAV files and put them under `data/train` etc.

3. Preprocess & Train:
   ```bash
   python src/train.py --data_dir PATH_TO_YOUR_DATA --epochs 30 --batch_size 16 --save_dir models/
   ```

4. Inference:
   ```bash
   python src/inference.py --model models/best.h5 --wav PATH_TO_WAV
   ```

## Notes
- This project uses CTC loss for alignment-free sequence training.
- Designed for learning and experimentation; for production-grade ASR you'd want  
  larger models, language model rescoring, beam search, augmentation, and more data.
- If you'd like, I can convert this to a PyTorch version, or add a pretrained model decoder.

## References
- TensorFlow CTC tutorial: https://www.tensorflow.org/tutorials/audio/speech_recognition (useful)
- LibriSpeech, Speech Commands datasets
